from __future__ import division
import Leap
import sys
import winsound
from Leap import CircleGesture, KeyTapGesture, ScreenTapGesture, SwipeGesture
import os
import pygame
import re
import math
import time
from pygame.locals import *
from pygame import midi

'''
Notes:  find time sig and bpm and correspond audio to that.
'''

timer = pygame.time.Clock()

pygame.midi.init()
b = False
pygame.init()

 #sets hardware surface
resolutions = pygame.display.list_modes()
horiz = int(resolutions[0][0] // 1.2)
vert = int(resolutions[0][1]  // 1.2)

#if not pygame.font: print 'Warning, fonts disabled'
if not pygame.mixer: print 'Warning, sound disabled'
bits = 16
pygame.mixer.pre_init(44100, -bits, 2,64)



gamecontinue = True
pattern = pygame.image.load("4-4pattern.png")
Main_Credit = pygame.image.load("images/main_credit.png")
Main_Default = pygame.image.load("images/main_default.png")
Main_Play = pygame.image.load("images/main_play.png")
Main_Instruct = pygame.image.load("images/main_instructions.png")
Song_Sel_def = pygame.image.load("images/Song_Sel_default.png")
Song_Sel_Mary = pygame.image.load("images/Song_Sel_Mary.png")
Song_Sel_Star = pygame.image.load("images/Song_Sel_Star.png")
Diff_Def = pygame.image.load("images/Difficulty_default.png")
Diff_Easy = pygame.image.load("images/Difficulty_easy.png")
Diff_Normal = pygame.image.load("images/Difficulty_Normal.png")
Score_Card = pygame.image.load("images/Score_Screen.png")
Instruction_Card = pygame.image.load("images/instructions.png")
Credits_Card = pygame.image.load("images/Credits.png")

GameFour = []
GameThree = []

GameFour = range(5)
GameThree = range(4)
    
GameFour[0] = pygame.image.load("images/Game_Mary_default.png")
GameFour[1] = pygame.image.load("images/Game_Mary_1.png")
GameFour[2] = pygame.image.load("images/Game_Mary_2.png")
GameFour[3] = pygame.image.load("images/Game_Mary_3.png")
GameFour[4] = pygame.image.load("images/Game_Mary_4.png")

GameThree[1] = pygame.image.load("images/Game_Star_1.png")
GameThree[2] = pygame.image.load("images/Game_Star_2.png")
GameThree[3] = pygame.image.load("images/Game_Star_3.png")
GameThree[0] = pygame.image.load("images/Game_Star_default.png")


Main_Default = pygame.transform.smoothscale(Main_Default, (horiz,vert))
Main_Credit = pygame.transform.smoothscale(Main_Credit, (horiz,vert))
Main_Play = pygame.transform.smoothscale(Main_Play, (horiz,vert))
Main_Instruct = pygame.transform.smoothscale(Main_Instruct, (horiz,vert))
Song_Sel_def = pygame.transform.smoothscale(Song_Sel_def, (horiz,vert))
Song_Sel_Mary = pygame.transform.smoothscale(Song_Sel_Mary, (horiz,vert))
Song_Sel_Star = pygame.transform.smoothscale(Song_Sel_Star, (horiz,vert))
Diff_Def = pygame.transform.smoothscale(Diff_Def, (horiz,vert))
Diff_Easy = pygame.transform.smoothscale(Diff_Easy, (horiz,vert))
Diff_Normal = pygame.transform.smoothscale(Diff_Normal, (horiz,vert))

Score_Card = pygame.transform.smoothscale(Score_Card, (horiz,vert))
Instruction_Card = pygame.transform.smoothscale(Instruction_Card, (horiz,vert))
Credits_Card = pygame.transform.smoothscale(Credits_Card, (horiz,vert))

GameFour[1] = pygame.transform.smoothscale(GameFour[1],(horiz,vert))
GameFour[2] = pygame.transform.smoothscale(GameFour[2],(horiz,vert))
GameFour[3] = pygame.transform.smoothscale(GameFour[3],(horiz,vert))
GameFour[4] = pygame.transform.smoothscale(GameFour[4],(horiz,vert))
GameFour[0] = pygame.transform.smoothscale(GameFour[0],(horiz,vert))
GameThree[1] = pygame.transform.smoothscale(GameThree[1],(horiz,vert))
GameThree[2] = pygame.transform.smoothscale(GameThree[2],(horiz,vert))
GameThree[3] = pygame.transform.smoothscale(GameThree[3],(horiz,vert))
GameThree[0] = pygame.transform.smoothscale(GameThree[0],(horiz,vert))


song_list = {}
song_list["MaryEasy"] = ["MaryEasy.mid", 4, GameFour,667]
song_list["MaryNormal"] = ["MaryNormal.mid",4, GameFour, 500]
song_list["StarEasy"] = ["StarEasy.mid", 3, GameThree, 1000]
song_list["StarNormal"] = ["StarNormal.mid",3, GameThree, 667]



xs = pygame.mixer.music
xs.set_endevent(pygame.USEREVENT)

class beatbox:
    def __init__(self,display_surf, listener, controller, song):
	self.display_surf = display_surf
        self.go = 0
        self.total = 0
        self.correct = 0
        self.beatArray = [] # stores array of pygame Rect objects
        self.beatCount = 0  # for looping through beat array
        self.b = False      # True or False triggered every second
	self.init_time = False
	self.playsound = 0
	self.midiName = song_list[song][0]
	self.timeSig = song_list[song][1]
	self.gameDisplay = song_list[song][2]
	self.beatsPerSec = song_list[song][3]
	self.start_song = False
	self.menu_check = 2
	xs.load(self.midiName)
	
	
        for i in range(4): #appends Rect object to the beat array 
            self.beatArray.append(pygame.Rect(0,0,horiz // 3.30,vert // 1.884))
        
        #moves the boxes for collision testing
        self.beatArray[0].center =(int(horiz // 2 ),int(vert // 1.258))
        self.beatArray[1].center =(int(horiz // 6.075),int(vert // 1.695))
        self.beatArray[2].center =(int(horiz // 1.2),int(vert // 1.695))
        self.beatArray[3].center = (int(horiz // 2),int(vert // 4.518))
	
	if self.timeSig == 3:
	    self.beatArray[1].center = (int(horiz // 1.2),int(vert // 1.695))
	    self.beatArray[2].center = (int(horiz // 2),int(vert // 4.518))
	    self.beatArray[3] = 0
	    
	    
    def time_sigs(self):
	pass
    
    def interaction(self,listener,controller):#checks for collisions and plays current note in song.
        quitter(listener,controller)
	
	pygame.display.flip() 
	if self.init_time == False:
	    self.playsound = USEREVENT + 1
	    pygame.time.set_timer(self.playsound, self.beatsPerSec)
	    
	    self.init_time = True
	if self.go < self.timeSig and pygame.event.get(self.playsound):
	    
	    fonts = pygame.font.Font(None,int(horiz // 1.92))
	    text = fonts.render(str(self.go + 1),1,(0,255,255))
	    self.display_surf.blit(self.gameDisplay[0], (0,0))
	    self.display_surf.blit(text,(horiz * .5,vert * .25))
	    pygame.draw.circle(self.display_surf,(0,255,0),(listener.directional['x'] ,-(listener.directional['y']) ), 10)
	  	    
	    self.go += 1
	    pygame.display.flip()
	    	    
	if self.go == self.timeSig:
	    if self.start_song == False:
		xs.play()
		self.start_song = True
	     
	    #self.display_surf.blit(self.gameDisplay[0], (0,0))
	    self.blip(self.beatCount + 1)
	    pygame.draw.circle(self.display_surf,(0,255,0),(listener.directional['x'] ,-(listener.directional['y']) ), 10)#prints a circle on the screen
	    
	    pygame.display.flip() 
		
	    	    	   
	    if pygame.event.get(self.playsound): #triggers event every second and updates beat spot and song note
		a = pygame.time.get_ticks()
		#print self.beatCount
		self.total += 1
		self.b = True
		if self.beatCount < self.timeSig -1:
		    self.beatCount += 1
		    
		else:
		    self.beatCount = 0
		  
		xs.set_volume(0.00)
					
	    
	    if (self.beatArray[self.beatCount ].collidepoint(listener.directional['x'] ,-(listener.directional['y'])) ):
		
		xs.set_volume(.99)
		if self.b == True:
		    self.correct += 1
		    print self.correct
		    self.b = False   
		self.blip(self.beatCount+1)  
		pygame.draw.circle(self.display_surf,(0,255,0),(listener.directional['x'] ,-(listener.directional['y'])), 10)
		
		pygame.display.flip()		
	for event in pygame.event.get():
	    if event.type == pygame.QUIT:
		controller.remove_listener(listener)
		pygame.quit()
		sys.exit()		
	    if event.type == pygame.USEREVENT:
		self.menu_check = 2.5
		
		return 
	    
    
    
        
    
    def blip(self, beatCount):
	if beatCount == self.timeSig:
	    beatCount = 0
	if(beatCount == 0 and self.timeSig == 4):
	    self.display_surf.blit(self.gameDisplay[4], (0,0))
	    
	elif(beatCount == 1 ):
	    self.display_surf.blit(self.gameDisplay[1], (0,0))
	    
	elif(beatCount == 2 ):
	    self.display_surf.blit(self.gameDisplay[2], (0,0))
	    
	elif(beatCount == 3 and self.timeSig ==4):
	    self.display_surf.blit(self.gameDisplay[3], (0,0))     
	
	elif (beatCount == 0 and self.timeSig == 3):
	    self.display_surf.blit(self.gameDisplay[3], (0,0))
        

class applistener(Leap.Listener):
    
    def on_init(self,controller):
        self.check = 0
        
	self.directional = {}
	self.directional['x'] = 0
	self.directional['y'] = 0
	self.directional['z'] = 0
        x = y = 0
        self._running = True 
        
        print "Connected"
        timerz = 0
    def on_connect(self,controller):
        print "Connected"
        
        controller.enable_gesture(Leap.Gesture.TYPE_SWIPE);
        
    def on_disconnect(self,controller):
        print "Disconnected"
        
    def on_exit(self,controller):
        print "Exited"
    def on_event(self, event):
        if event.type == QUIT:
            self._running = False
        return self._running
    def on_loop(self, end):
        print "hello"
        
        if self.running == False:
            return False
        else:
            return True
    def exits(self):
        return False
    
    
    def on_cleanup(self):
        if self.on_loop == True:
            return False
    
    
    def on_frame(self,controller):#Leap motion loop listens for any interaction with Leap Motion device

        frame = controller.frame()  
         #polls for any user input events
        iBox = frame.interaction_box
            
            
        
        
        if not frame.hands.is_empty:#Checks for hands or pointables over Leap
            
            hand = frame.hands[0] # fingers on first hand
            hand2 = frame.hands[1]# fingers on second hand
            
            fingers1 = hand.fingers # list of fingers from first hand
            fingers2 = hand2.fingers # list of fingers from second hand
            if not frame.fingers.is_empty:#checks fingers
                if not fingers1.is_empty: #checks if fingers from first hand are present
                    
                    #print iBox.width , iBox.height
		    screenPosition = iBox.normalize_point(fingers1[0].tip_position)
		    self.directional['x'] = int(screenPosition[0] * horiz)
		    self.directional['y'] = -(vert - int(screenPosition[1] * vert))
		    #print self.directional['x'],self.directional['y']
		    
                    
        for gesture in frame.gestures(): #reads in a swipe gesture
            if gesture.type == Leap.Gesture.TYPE_SWIPE:
                swipe = SwipeGesture(gesture)
                #print self.state_string(gesture.state)
                #print swipe.start_position
                #print swipe.direction
                #print swipe.position
                self.on_cleanup()
       
        
    def state_string(self, state):
        if state == Leap.Gesture.STATE_START:
            return "STATE_START"

        if state == Leap.Gesture.STATE_UPDATE:
            return "STATE_UPDATE"

        if state == Leap.Gesture.STATE_STOP:
            return "STATE_STOP"

        if state == Leap.Gesture.STATE_INVALID:
            return "STATE_INVALID"

def midis():
    pass
    #coun = pygame.midi.get_count()
    #print coun
class cursor:
    def __init__(self,display_surf):
	self.x = 0
	self.y = 0
	self.display = display_surf
	
    def cursorPrint(self,x,y):
	pygame.draw.circle(self.display,(0,255,0),(x ,y ), 10)
	self.x = x
	self.y = y
    def cursorPos(self):
	print self.x,self.y
	return (self.x, self.y) 

class songs:
    def __init__(self):
	self.songName
	self.timeSig
	self.midiName
    def name(self):
	return self.songName
    def time_sig(self):
	return self.timeSig
    def midi_name(self):
	return self.midiName

def quitter(listener,controller):
    for event in pygame.event.get():
	if event.type == pygame.QUIT:
	    controller.remove_listener(listener)
	    pygame.quit()
	    sys.exit()    

class menus:
    
    def __init__(self,display_surf):
	pygame.font.init()
	self.display_surf = display_surf
	self.menu_index = 0
	self.main_buttons = {}
	self.ButPress = 0
	self.ButTimer = pygame.time
	self.button = USEREVENT + 1
	self.ButTimer.set_timer(self.button, 2000)
	self.grow = 0
	
	self.back_button = {}
	self.song_buttons = {}
	self.diff_buttons = {}
	self.song_choice = ""
	
    def main_menu(self,listener,controller):
	quitter(listener,controller)	
	self.display_surf.fill((0,0,0))
	self.display_surf.blit(Main_Default, (0,0))
	
	
	self.main_buttons["play"] = [pygame.Rect(0,0,horiz // 5.333,vert //3.00),1,Main_Play]
	self.main_buttons["play"][0].center = (int(horiz // 3.64),int(vert // 1.70))
	self.main_buttons["instructions"] = [pygame.Rect(0,0,horiz // 5.333,vert //3.00),3,Main_Instruct]
	self.main_buttons["instructions"][0].center = (int(horiz // 1.97),int(vert // 1.70))
	self.main_buttons["credits"] = [pygame.Rect(0,0,horiz // 5.333,vert //3.00), 4,Main_Credit]
	self.main_buttons["credits"][0].center = (int(horiz // 1.35),int(vert // 1.70))
	'''
	pygame.draw.rect(self.display_surf, (255,0,0), self.menu_dict["play"][0], 2)
	pygame.draw.rect(self.display_surf, (255,0,0), self.menu_dict["instructions"][0], 2)
	pygame.draw.rect(self.display_surf, (255,0,0), self.menu_dict["credits"][0], 2)
	''' 
	pygame.draw.circle(self.display_surf,(0,255,0),(listener.directional['x'] ,-(listener.directional['y']) ), 10)
	self.buttonPress(self.main_buttons,listener,controller)
	    
	    
	pygame.display.flip()
	
    def song_sel(self,listener,controller):
	quitter(listener,controller)	
	self.display_surf.fill((0,0,0))
	
	self.display_surf.blit(Song_Sel_def, (0,0))
	pygame.draw.circle(self.display_surf,(0,255,0),(listener.directional['x'] ,-(listener.directional['y']) ), 10)
	self.song_buttons["Mary"] = [pygame.Rect(int(horiz // 4.304),int(vert // 2.432),int(horiz // 1.732),int(vert // 14.794)),1.5,Song_Sel_Mary]
	self.song_buttons["Star"] = [pygame.Rect(int(horiz // 4.304),int(vert // 2.08),int(horiz // 1.732),int(vert // 14.794)),1.5,Song_Sel_Star]
	self.song_buttons["Back"] = [pygame.Rect(int(horiz // 1.327),int(vert // 3.506),int(horiz // 16.991),int(vert // 20.377)),0,Song_Sel_def]
	
		
	self.buttonPress(self.song_buttons,listener,controller)
	    
	pygame.display.flip()
    
    def diff_sel(self, listener,controller):
	quitter(listener,controller)
	self.display_surf.blit(Diff_Def, (0,0))
	pygame.draw.circle(self.display_surf,(0,255,0),(listener.directional['x'] ,-(listener.directional['y']) ), 10)
	self.diff_buttons["Easy"] = [pygame.Rect(int(horiz // 5.485),int(vert // 3.085),int(horiz // 3.205),int(vert // 2.264)),2,Diff_Easy]
	self.diff_buttons["Normal"] = [pygame.Rect(int(horiz // 1.92),int(vert // 3.085),int(horiz // 3.205),int(vert // 2.264)),2,Diff_Normal]
	self.diff_buttons["Back"] = [pygame.Rect(int(horiz // 1.327),int(vert // 3.506),int(horiz // 16.991),int(vert // 20.377)),1,Diff_Def]
	
		
	self.buttonPress(self.diff_buttons,listener,controller)
	    
	pygame.display.flip()	
	
    def score_screen(self, listener,controller, total, correct):
	quitter(listener,controller)
	correct_beats = correct
	total_beats = total
	self.back_button["Back"] = [pygame.Rect(int(horiz // 40.327),int(vert // 1.506),int(horiz // 3.291),int(vert // 2.377)),0,Score_Card]
	print correct_beats
	print total_beats
	percent = int(100 * float(correct_beats / total_beats))
	fonts = pygame.font.Font(None,int(horiz // 15.92))
	text1 = fonts.render("You got " + str(correct_beats) + " out of " + str(total_beats),1,(0,0,0))
	text2 = fonts.render("Thats " + str(percent) + " percent!",1,(0,0,0))
	
	self.display_surf.blit(Score_Card, (0,0))
	self.display_surf.blit(text1,(horiz * .5,vert * .25))
	self.display_surf.blit(text2,(horiz * .5,vert * .5))
	pygame.draw.circle(self.display_surf,(0,255,0),(listener.directional['x'] ,-(listener.directional['y']) ), 10)
	
	self.buttonPress(self.back_button,listener,controller)
	
	pygame.display.flip()
	
    def instructions_screen(self, listener,controller):
	quitter(listener,controller)
	self.back_button["Back"] = [pygame.Rect(int(horiz // 1.127),int(vert // 37.206),int(horiz // 3.291),int(vert // 2.377)),0,Instruction_Card]
	self.display_surf.blit(Instruction_Card, (0,0))
	
	
	pygame.draw.circle(self.display_surf,(0,255,0),(listener.directional['x'] ,-(listener.directional['y']) ), 10)
		
	self.buttonPress(self.back_button,listener,controller)
	
	pygame.display.flip()
	
    def credits_screen(self,listener, controller):
	quitter(listener,controller)
	self.back_button["Back"] = [pygame.Rect(int(horiz // 1.127),int(vert // 37.206),int(horiz // 3.291),int(vert // 2.377)),0,Credits_Card]
	self.display_surf.blit(Credits_Card, (0,0))
	
	
	pygame.draw.circle(self.display_surf,(0,255,0),(listener.directional['x'] ,-(listener.directional['y']) ), 10)
		
	self.buttonPress(self.back_button,listener,controller)
		
	pygame.display.flip()	
    def buttonPress(self,butPress,listener,controller):
	for i in butPress:
	    while butPress[i][0].collidepoint(listener.directional['x'] ,-(listener.directional['y'])):
		self.grow = self.grow + .25
		if self.grow > 25:
		    self.grow = 0
		
		self.display_surf.blit(butPress[i][2], (0,0))
		pygame.draw.circle(self.display_surf,(0,255,0),(listener.directional['x'] ,-(listener.directional['y']) ), 10 + int(self.grow), 2)
		pygame.draw.circle(self.display_surf,(0,255,0),(listener.directional['x'] ,-(listener.directional['y']) ), 10)
		
		pygame.display.flip()
		if pygame.event.get(self.button):
		    
		    if butPress[i][1] == 1.5:
			self.song_choice = i
		    if butPress[i][1] == 2:
			self.song_choice += i
		    self.menu_index = butPress[i][1]
		    return	
	    self.grow = 0
	    self.ButTimer.set_timer(self.button, 2000)	    


def pygameLoop(controller, listener):
    check = 0
    
    display_surf = pygame.display.set_mode((horiz,vert), pygame.HWSURFACE) #sets hardware surface
    menuNum = 0
    
    menu = menus(display_surf)
    
    
    
    #self._image_surf = pygame.image.load("myimage.jpg").convert()
    print "Connected"
    
    
    while True:
	for event in pygame.event.get():
	    if event.type == pygame.QUIT:
		controller.remove_listener(listener)
		pygame.quit()
		sys.exit()
	if (menu.menu_index == 0):
	    menu.main_menu(listener,controller)
	while(menu.menu_index == 1):
	    menu.song_sel(listener,controller)
	while(menu.menu_index == 1.5):
	    menu.diff_sel(listener,controller)
	    
	if menu.menu_index == 2:
	    beatboxes = beatbox(display_surf,listener, controller, menu.song_choice)
	while(menu.menu_index == 2):
	    
	    beatboxes.interaction(listener,controller)
	    menu.menu_index = beatboxes.menu_check
	while(menu.menu_index == 2.5):
	    
	    menu.score_screen(listener,controller,beatboxes.total,beatboxes.correct)
	while(menu.menu_index == 3):
	    menu.instructions_screen(listener,controller)
	    
	while(menu.menu_index == 4):
	    menu.credits_screen(listener,controller)
def main():
    
    controller = Leap.Controller()
    applistener1 = applistener()
    controller.add_listener(applistener1)
    
    
    print "Press Enter to quit..."
   
    #sys.stdin.readline()
    
    pygameLoop(controller,applistener1)
    controller.remove_listener(applistener1)
    
    
if __name__ == "__main__":
    main()