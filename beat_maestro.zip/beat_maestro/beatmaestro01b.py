'''
beatmaestro01b.py

Destiny Bonollo, Meghan Dorian, and Alexander Taoultsides
Project Broomstick

This app is designed to teach the user how to conduct using the LEAP motion 
device as the input.  The user chooses a song and difficulty which corresponds to 
an audio file that has been pre-processed and hard coded into the program.

The user is supposed to follow the conducting pattern designated by blinking circles
and use their finger to enter the space of the beat circle.  If the user fails to make
it to a beat at the right time, then the music will not play and the user does not get 
credit for that beat.  

A score screen displays the percentage right.

'''

from __future__ import division
import Leap
import sys
import winsound
from Leap import CircleGesture, KeyTapGesture, ScreenTapGesture, SwipeGesture
import os
import pygame
import re
import math
import time
from pygame.locals import *
from pygame import midi



timer = pygame.time.Clock()

pygame.midi.init() #initializes pygames midi module
b = False
pygame.init() #init midi

 #sets hardware surface resolutions
resolutions = pygame.display.list_modes() #list of all resolutions starting from Native
horiz = int(resolutions[0][0] // 1.2) 
vert = int(resolutions[0][1]  // 1.2)

#if not pygame.font: print 'Warning, fonts disabled'
if not pygame.mixer: print 'Warning, sound disabled'
bits = 16
pygame.mixer.pre_init(44100, -bits, 2,64)



#loads all images
pattern = pygame.image.load("4-4pattern.png")
Main_Credit = pygame.image.load("images/main_credit.png")
Main_Default = pygame.image.load("images/main_default.png")
Main_Play = pygame.image.load("images/main_play.png")
Main_Instruct = pygame.image.load("images/main_instructions.png")
Song_Sel_def = pygame.image.load("images/Song_Sel_default.png")
Song_Sel_Mary = pygame.image.load("images/Song_Sel_Mary.png")
Song_Sel_Star = pygame.image.load("images/Song_Sel_Star.png")
Diff_Def = pygame.image.load("images/Difficulty_default.png")
Diff_Easy = pygame.image.load("images/Difficulty_easy.png")
Diff_Normal = pygame.image.load("images/Difficulty_Normal.png")
Score_Card = pygame.image.load("images/Score_Screen.png")
Instruction_Card = pygame.image.load("images/instructions.png")
Credits_Card = pygame.image.load("images/Credits.png")


GameFour = range(5)#image list for game screen images using 4/4
GameThree = range(4)#image list for game screen images using 3/4
    
GameFour[0] = pygame.image.load("images/Game_Mary_default.png")
GameFour[1] = pygame.image.load("images/Game_Mary_1.png")
GameFour[2] = pygame.image.load("images/Game_Mary_2.png")
GameFour[3] = pygame.image.load("images/Game_Mary_3.png")
GameFour[4] = pygame.image.load("images/Game_Mary_4.png")

GameThree[1] = pygame.image.load("images/Game_Star_1.png")
GameThree[2] = pygame.image.load("images/Game_Star_2.png")
GameThree[3] = pygame.image.load("images/Game_Star_3.png")
GameThree[0] = pygame.image.load("images/Game_Star_default.png")


#transforms all images to look smooth on the display and scales to the resolution selected above
Main_Default = pygame.transform.smoothscale(Main_Default, (horiz,vert))
Main_Credit = pygame.transform.smoothscale(Main_Credit, (horiz,vert))
Main_Play = pygame.transform.smoothscale(Main_Play, (horiz,vert))
Main_Instruct = pygame.transform.smoothscale(Main_Instruct, (horiz,vert))
Song_Sel_def = pygame.transform.smoothscale(Song_Sel_def, (horiz,vert))
Song_Sel_Mary = pygame.transform.smoothscale(Song_Sel_Mary, (horiz,vert))
Song_Sel_Star = pygame.transform.smoothscale(Song_Sel_Star, (horiz,vert))
Diff_Def = pygame.transform.smoothscale(Diff_Def, (horiz,vert))
Diff_Easy = pygame.transform.smoothscale(Diff_Easy, (horiz,vert))
Diff_Normal = pygame.transform.smoothscale(Diff_Normal, (horiz,vert))

Score_Card = pygame.transform.smoothscale(Score_Card, (horiz,vert))
Instruction_Card = pygame.transform.smoothscale(Instruction_Card, (horiz,vert))
Credits_Card = pygame.transform.smoothscale(Credits_Card, (horiz,vert))

GameFour[1] = pygame.transform.smoothscale(GameFour[1],(horiz,vert))
GameFour[2] = pygame.transform.smoothscale(GameFour[2],(horiz,vert))
GameFour[3] = pygame.transform.smoothscale(GameFour[3],(horiz,vert))
GameFour[4] = pygame.transform.smoothscale(GameFour[4],(horiz,vert))
GameFour[0] = pygame.transform.smoothscale(GameFour[0],(horiz,vert))
GameThree[1] = pygame.transform.smoothscale(GameThree[1],(horiz,vert))
GameThree[2] = pygame.transform.smoothscale(GameThree[2],(horiz,vert))
GameThree[3] = pygame.transform.smoothscale(GameThree[3],(horiz,vert))
GameThree[0] = pygame.transform.smoothscale(GameThree[0],(horiz,vert))


song_list = {}
song_list["MaryEasy"] = ["MaryEasy.mid", 4, GameFour,667]
song_list["MaryNormal"] = ["MaryNormal.mid",4, GameFour, 500]
song_list["StarEasy"] = ["StarEasy.mid", 3, GameThree, 1000]
song_list["StarNormal"] = ["StarNormal.mid",3, GameThree, 667]



mix = pygame.mixer.music #mixer that streams song for game
mix.set_endevent(pygame.USEREVENT) #event for when mix ends

'''
beatbox is the actual game
'''
class beatbox:
    def __init__(self,display_surf, listener, controller, song):
	self.display_surf = display_surf
        self.go = 0  #countdown for game to start
        self.total = 0 #total number of beats 
        self.correct = 0 #correct number of beats
        self.beatArray = [] # stores array of pygame Rect objects
        self.beatCount = 0  # for looping through beat array
        self.b = False      # True or False triggered every second
	self.init_time = False #to set the beats ber minute of the song
	self.playsound = 0 #playsound is the userevent for when the beat hits
	self.midiName = song_list[song][0] #name of the midi file
	self.timeSig = song_list[song][1] #time signature for that song
	self.gameDisplay = song_list[song][2] #list of displays depending on whether 4/4 or 3/4 timing
	self.beatsPerSec = song_list[song][3] #beat speed in milliseconds
	self.start_song = False 
	self.menu_check = 2 
	mix.load(self.midiName) #loads 
	
	
        for i in range(4): #appends Rect object to the beat array 
            self.beatArray.append(pygame.Rect(0,0,horiz // 3.30,vert // 1.884))
        
        #moves the boxes for collision testing
        self.beatArray[0].center =(int(horiz // 2 ),int(vert // 1.258))
        self.beatArray[1].center =(int(horiz // 6.075),int(vert // 1.695))
        self.beatArray[2].center =(int(horiz // 1.2),int(vert // 1.695))
        self.beatArray[3].center = (int(horiz // 2),int(vert // 4.518))
	#moves boxes in case time signature is in 3/4
	if self.timeSig == 3:
	    self.beatArray[1].center = (int(horiz // 1.2),int(vert // 1.695))
	    self.beatArray[2].center = (int(horiz // 2),int(vert // 4.518))
	    self.beatArray[3] = 0
	    
	    
 
    
    def interaction(self,listener,controller):#checks for collisions and plays current note in song.
        quitter(listener,controller)
	
	pygame.display.flip() 
	if self.init_time == False:
	    self.playsound = USEREVENT + 1
	    pygame.time.set_timer(self.playsound, self.beatsPerSec)
	    
	    self.init_time = True
	if self.go < self.timeSig and pygame.event.get(self.playsound): #displays countdown in the bpm of the song e.g. 1 ,2 ,3 ,4
	    
	    fonts = pygame.font.Font(None,int(horiz // 1.92)) #display text
	    text = fonts.render(str(self.go + 1),1,(0,255,255))
	    self.display_surf.blit(self.gameDisplay[0], (0,0))
	    self.display_surf.blit(text,(horiz * .5,vert * .25))
	    pygame.draw.circle(self.display_surf,(0,255,0),(listener.directional['x'] ,-(listener.directional['y']) ), 10)
	  	    
	    self.go += 1
	    pygame.display.flip()
	    	    
	if self.go == self.timeSig: #game starts and song plays
	    if self.start_song == False:
		mix.play()
		self.start_song = True
	     
	    
	    self.blip(self.beatCount + 1)
	    pygame.draw.circle(self.display_surf,(0,255,0),(listener.directional['x'] ,-(listener.directional['y']) ), 10)#prints a circle on the screen
	    
	    pygame.display.flip() 
		
	    	    	   
	    if pygame.event.get(self.playsound): #triggers event every second and updates beat spot and song note
		a = pygame.time.get_ticks()
		#print self.beatCount
		self.total += 1 #adds to total beats in song
		self.b = True #boolean to show if a beat has been hit so it does not constantly increment the score every loop
		if self.beatCount < self.timeSig -1: #beat count cycles through the beats.
		    self.beatCount += 1
		    
		else:
		    self.beatCount = 0
		  
		mix.set_volume(0.00)
					
	    
	    if (self.beatArray[self.beatCount ].collidepoint(listener.directional['x'] ,-(listener.directional['y'])) ):
		
		mix.set_volume(.99) #if cursor is hitting the right beat then the volume is up all the way and correct score is incremented
		if self.b == True:
		    self.correct += 1
		    print self.correct
		    self.b = False   
		self.blip(self.beatCount+1)  
		pygame.draw.circle(self.display_surf,(0,255,0),(listener.directional['x'] ,-(listener.directional['y'])), 10)
		
		pygame.display.flip()
		
	for event in pygame.event.get(): #checks to see if user has quit or the song has ended.
	    if event.type == pygame.QUIT:
		controller.remove_listener(listener)
		pygame.quit()
		sys.exit()		
	    if event.type == pygame.USEREVENT:
		self.menu_check = 2.5
		
		return 
	
    def blip(self, beatCount): #displays the game screen for each beat with checks determining 3/4 or 4/4 timing.
	if beatCount == self.timeSig:
	    beatCount = 0
	if(beatCount == 0 and self.timeSig == 4):
	    self.display_surf.blit(self.gameDisplay[4], (0,0))
	    
	elif(beatCount == 1 ):
	    self.display_surf.blit(self.gameDisplay[1], (0,0))
	    
	elif(beatCount == 2 ):
	    self.display_surf.blit(self.gameDisplay[2], (0,0))
	    
	elif(beatCount == 3 and self.timeSig ==4):
	    self.display_surf.blit(self.gameDisplay[3], (0,0))     
	
	elif (beatCount == 0 and self.timeSig == 3):
	    self.display_surf.blit(self.gameDisplay[3], (0,0))
        

class applistener(Leap.Listener):
    
    def on_init(self,controller):
        self.check = 0
        
	self.directional = {}
	self.directional['x'] = 0
	self.directional['y'] = 0
	self.directional['z'] = 0
        x = y = 0
        self._running = True 
        
        print "Connected"
        timerz = 0
    def on_connect(self,controller):
        print "Connected"
        
        controller.enable_gesture(Leap.Gesture.TYPE_SWIPE);
        
    def on_disconnect(self,controller):
        print "Disconnected"
        
    def on_exit(self,controller):
        print "Exited"
    def on_event(self, event):
        if event.type == QUIT:
            self._running = False
        return self._running
    def on_loop(self, end):
        print "hello"
        
        if self.running == False:
            return False
        else:
            return True
    def exits(self):
        return False
    
    
    def on_cleanup(self):
        if self.on_loop == True:
            return False
    
    
    def on_frame(self,controller):#Leap motion loop listens for any interaction with Leap Motion device

        frame = controller.frame()  
         #polls for any user input events
        iBox = frame.interaction_box
            
            
        
        
        if not frame.hands.is_empty:#Checks for hands or pointables over Leap
            
            hand = frame.hands[0] # fingers on first hand
            hand2 = frame.hands[1]# fingers on second hand
            
            fingers1 = hand.fingers # list of fingers from first hand
            fingers2 = hand2.fingers # list of fingers from second hand
            if not frame.fingers.is_empty:#checks fingers
                if not fingers1.is_empty: #checks if fingers from first hand are present
                    
                    #print iBox.width , iBox.height
		    screenPosition = iBox.normalize_point(fingers1[0].tip_position)
		    self.directional['x'] = int(screenPosition[0] * horiz)
		    self.directional['y'] = -(vert - int(screenPosition[1] * vert))
		    #print self.directional['x'],self.directional['y']
		    
                    
        for gesture in frame.gestures(): #reads in a swipe gesture
            if gesture.type == Leap.Gesture.TYPE_SWIPE:
                swipe = SwipeGesture(gesture)
                #print self.state_string(gesture.state)
                #print swipe.start_position
                #print swipe.direction
                #print swipe.position
                self.on_cleanup()
       
        
    def state_string(self, state):
        if state == Leap.Gesture.STATE_START:
            return "STATE_START"

        if state == Leap.Gesture.STATE_UPDATE:
            return "STATE_UPDATE"

        if state == Leap.Gesture.STATE_STOP:
            return "STATE_STOP"

        if state == Leap.Gesture.STATE_INVALID:
            return "STATE_INVALID"



def quitter(listener,controller): #checks to see if user has "exed" out of app.
    for event in pygame.event.get():
	if event.type == pygame.QUIT:
	    controller.remove_listener(listener)
	    pygame.quit()
	    sys.exit()    

class menus:
    
    def __init__(self,display_surf):
	pygame.font.init()
	self.display_surf = display_surf 
	self.menu_index = 0  #index number for which menu to use
	
	self.ButPress = 0    #ButPress is the list of keys in the dictionary of buttons
	self.ButTimer = pygame.time #Sets cursor hover time for 2 seconds before next screen is selected
	self.button = USEREVENT + 1
	self.ButTimer.set_timer(self.button, 2000)
	self.grow = 0 #grows the circle for the cursor hover animation
	
	self.main_buttons = {} #dictionary of buttons that are used for each screen
	self.back_button = {} 
	self.song_buttons = {}
	self.diff_buttons = {}
	self.song_choice = "" #chosen song
	
	
	'''
	   Each method is a menu page.  Each page calls the blit function for the display surface and 
	   displays the various images associated with that page as declared above.
	'''
    def main_menu(self,listener,controller): 
	quitter(listener,controller)	
	self.display_surf.fill((0,0,0))
	self.display_surf.blit(Main_Default, (0,0))
	
	#Each button is in the form of a list containing the information for the size of the 
	#button rectangle, the next menu in the form of an integer, and the image to be displayed when
	#a collidepoint is selected.
	self.main_buttons["play"] = [pygame.Rect(0,0,horiz // 5.333,vert //3.00),1,Main_Play] 
	self.main_buttons["play"][0].center = (int(horiz // 3.64),int(vert // 1.70))
	self.main_buttons["instructions"] = [pygame.Rect(0,0,horiz // 5.333,vert //3.00),3,Main_Instruct]
	self.main_buttons["instructions"][0].center = (int(horiz // 1.97),int(vert // 1.70))
	self.main_buttons["credits"] = [pygame.Rect(0,0,horiz // 5.333,vert //3.00), 4,Main_Credit]
	self.main_buttons["credits"][0].center = (int(horiz // 1.35),int(vert // 1.70))
	
	pygame.draw.circle(self.display_surf,(0,255,0),(listener.directional['x'] ,-(listener.directional['y']) ), 10)
	
	self.buttonPress(self.main_buttons,listener,controller) #animation for button hover press and selects next menu page
	    
	    
	pygame.display.flip()
	
    def song_sel(self,listener,controller):
	quitter(listener,controller)	
	self.display_surf.fill((0,0,0))
	
	self.display_surf.blit(Song_Sel_def, (0,0))
	pygame.draw.circle(self.display_surf,(0,255,0),(listener.directional['x'] ,-(listener.directional['y']) ), 10)
	self.song_buttons["Mary"] = [pygame.Rect(int(horiz // 4.304),int(vert // 2.432),int(horiz // 1.732),int(vert // 14.794)),1.5,Song_Sel_Mary]
	self.song_buttons["Star"] = [pygame.Rect(int(horiz // 4.304),int(vert // 2.08),int(horiz // 1.732),int(vert // 14.794)),1.5,Song_Sel_Star]
	self.song_buttons["Back"] = [pygame.Rect(int(horiz // 1.327),int(vert // 3.506),int(horiz // 16.991),int(vert // 20.377)),0,Song_Sel_def]
	
		
	self.buttonPress(self.song_buttons,listener,controller)
	    
	pygame.display.flip()
    
    def diff_sel(self, listener,controller):
	quitter(listener,controller)
	self.display_surf.blit(Diff_Def, (0,0))
	pygame.draw.circle(self.display_surf,(0,255,0),(listener.directional['x'] ,-(listener.directional['y']) ), 10)
	self.diff_buttons["Easy"] = [pygame.Rect(int(horiz // 5.485),int(vert // 3.085),int(horiz // 3.205),int(vert // 2.264)),2,Diff_Easy]
	self.diff_buttons["Normal"] = [pygame.Rect(int(horiz // 1.92),int(vert // 3.085),int(horiz // 3.205),int(vert // 2.264)),2,Diff_Normal]
	self.diff_buttons["Back"] = [pygame.Rect(int(horiz // 1.327),int(vert // 3.506),int(horiz // 16.991),int(vert // 20.377)),1,Diff_Def]
	
		
	self.buttonPress(self.diff_buttons,listener,controller)
	    
	pygame.display.flip()	
	
    def score_screen(self, listener,controller, total, correct): #Loop for score screen
	quitter(listener,controller)
	correct_beats = correct
	total_beats = total
	self.back_button["Back"] = [pygame.Rect(int(horiz // 40.327),int(vert // 1.506),int(horiz // 3.291),int(vert // 2.377)),0,Score_Card]
	print correct_beats
	print total_beats
	percent = int(100 * float(correct_beats / total_beats))
	fonts = pygame.font.Font(None,int(horiz // 15.92))
	text1 = fonts.render("You got " + str(correct_beats) + " out of " + str(total_beats),1,(0,0,0))
	text2 = fonts.render("Thats " + str(percent) + " percent!",1,(0,0,0))
	
	self.display_surf.blit(Score_Card, (0,0))
	self.display_surf.blit(text1,(horiz * .5,vert * .25))
	self.display_surf.blit(text2,(horiz * .5,vert * .5))
	pygame.draw.circle(self.display_surf,(0,255,0),(listener.directional['x'] ,-(listener.directional['y']) ), 10)
	
	self.buttonPress(self.back_button,listener,controller)
	
	pygame.display.flip()
	
    def instructions_screen(self, listener,controller):#loop for instructions screen
	quitter(listener,controller)
	self.back_button["Back"] = [pygame.Rect(int(horiz // 1.127),int(vert // 37.206),int(horiz // 3.291),int(vert // 2.377)),0,Instruction_Card]
	self.display_surf.blit(Instruction_Card, (0,0))
	
	
	pygame.draw.circle(self.display_surf,(0,255,0),(listener.directional['x'] ,-(listener.directional['y']) ), 10)
		
	self.buttonPress(self.back_button,listener,controller)
	
	pygame.display.flip()
	
    def credits_screen(self,listener, controller):
	quitter(listener,controller)
	self.back_button["Back"] = [pygame.Rect(int(horiz // 1.127),int(vert // 37.206),int(horiz // 3.291),int(vert // 2.377)),0,Credits_Card] #back button
	self.display_surf.blit(Credits_Card, (0,0))
	
	
	pygame.draw.circle(self.display_surf,(0,255,0),(listener.directional['x'] ,-(listener.directional['y']) ), 10)
		
	self.buttonPress(self.back_button,listener,controller)
		
	pygame.display.flip()
	
	
    def buttonPress(self,butPress,listener,controller): #animates button press when cursor is colliding with a rect.
	for i in butPress:
	    while butPress[i][0].collidepoint(listener.directional['x'] ,-(listener.directional['y'])):
		self.grow = self.grow + .25
		if self.grow > 25:
		    self.grow = 0
		
		self.display_surf.blit(butPress[i][2], (0,0))
		pygame.draw.circle(self.display_surf,(0,255,0),(listener.directional['x'] ,-(listener.directional['y']) ), 10 + int(self.grow), 2)
		pygame.draw.circle(self.display_surf,(0,255,0),(listener.directional['x'] ,-(listener.directional['y']) ), 10)
		
		pygame.display.flip()
		if pygame.event.get(self.button):
		    
		    if butPress[i][1] == 1.5:
			self.song_choice = i
		    if butPress[i][1] == 2:
			self.song_choice += i
		    self.menu_index = butPress[i][1]
		    return	
	    self.grow = 0
	    self.ButTimer.set_timer(self.button, 2000)	    


def pygameLoop(controller, listener):
    check = 0
    
    display_surf = pygame.display.set_mode((horiz,vert), pygame.HWSURFACE) #sets hardware surface
    menuNum = 0
    
    menu = menus(display_surf)
    
    
    
    #self._image_surf = pygame.image.load("myimage.jpg").convert()
    print "Connected"
    
    
    while True:
	for event in pygame.event.get():
	    if event.type == pygame.QUIT:
		controller.remove_listener(listener)
		pygame.quit()
		sys.exit()
	if (menu.menu_index == 0):
	    menu.main_menu(listener,controller) #main menu
	while(menu.menu_index == 1):
	    menu.song_sel(listener,controller) # song selection overlay
	while(menu.menu_index == 1.5):
	    menu.diff_sel(listener,controller) #difficulty selection overlay
	    
	if menu.menu_index == 2:
	    beatboxes = beatbox(display_surf,listener, controller, menu.song_choice) #init beatbox game with chosen song. easy or normal.
	while(menu.menu_index == 2):
	    
	    beatboxes.interaction(listener,controller) #actual game
	    menu.menu_index = beatboxes.menu_check
	while(menu.menu_index == 2.5):
	    
	    menu.score_screen(listener,controller,beatboxes.total,beatboxes.correct)#score screen
	while(menu.menu_index == 3):
	    menu.instructions_screen(listener,controller) # instruction screen
	    
	while(menu.menu_index == 4):
	    menu.credits_screen(listener,controller) #credits screen
def main():
    
    controller = Leap.Controller()
    applistener1 = applistener()
    controller.add_listener(applistener1)
    
    
    print "Press Enter to quit..."
   
    #sys.stdin.readline()
    
    pygameLoop(controller,applistener1)
    controller.remove_listener(applistener1)
    
    
if __name__ == "__main__":
    main()